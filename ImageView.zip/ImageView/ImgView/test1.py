import time
def main1(parameter):
    if parameter == "1":
        print("im 1")
    elif parameter == "2":
        print("im 2")
    elif parameter =="3":
        print("im 3")
    else:
        print("parameter wrong")
 
# if __name__=="main":,  
# while True:
# main("1")
# time.sleep(1)
# main("2")
# time.sleep(1)
