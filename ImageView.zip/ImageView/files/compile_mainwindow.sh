#!/bin/bash
pyuic5 -o ../mainwindow.py mainwindow.ui
