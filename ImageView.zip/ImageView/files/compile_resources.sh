#!/bin/bash
pyrcc5 -o ../resources_rc.py resources.qrc