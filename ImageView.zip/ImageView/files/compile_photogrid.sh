#!/bin/bash
pyuic5 -o ../photogrid_dialog.py photogrid-dialog.ui
