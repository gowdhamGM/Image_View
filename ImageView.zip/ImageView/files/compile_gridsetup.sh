#!/bin/bash
pyuic5 -o ../gridsetup_dialog.py gridsetup-dialog.ui
