#!/bin/bash
pyuic5 -o ../addborder_dialog.py addborder_dialog.ui
