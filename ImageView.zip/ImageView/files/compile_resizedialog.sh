#!/bin/bash
pyuic5 -o ../resize_dialog.py resize_dialog.ui
